pth = 'C:/Users/james/Desktop/tests/model/'
